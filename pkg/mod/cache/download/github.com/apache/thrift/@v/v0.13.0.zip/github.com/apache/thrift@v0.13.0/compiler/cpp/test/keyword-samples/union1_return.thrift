union return {}
