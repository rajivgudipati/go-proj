# Contributing to sketches-go 

First of all, thanks for contributing!

* If you think you've found an issue, please open a Github issue.
* To propose improvements, feel free to submit a PR.
