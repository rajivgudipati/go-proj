struct struct_name {
  1: required bool return = 1
}
